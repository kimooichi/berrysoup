function show_popup()
{
    document.getElementsByClassName("Images").style.display="block";
    document.getElementsByClassName("Images").style.opacity="0";
    setTimeout(popup_fade_in,5); //call next function after 5ms
}

function popup_fade_in()
{
    document.getElementsByClassName("Images").style.opacity="100";
}

function hide_popup()
{
    document.getElementsByClassName("Images").style.opacity="0";
    setTimeout(popup_display_none,500);
}

function popup_display_none()
{
    document.getElementsByClassName("Images").style.display="none";
}
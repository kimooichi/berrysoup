function myFunction()
{
    console.log("CLICKED")
}